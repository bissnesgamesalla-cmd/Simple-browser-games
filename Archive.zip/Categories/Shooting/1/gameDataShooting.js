//  1 gamesDataShooting.js
const allGamesDataShooting = [
    {
        // Tank War Simulator Game
        title: "Escape Police for Brainrots",
        link: "Categories/Shooting/1/Terrifying-Zombies-Tower-Defense-1-Game.html",
        image: "Categories/Shooting/1/icon games/_Terrifying Zombies  Tower Defense 1 Game-512x384 (1).webp",
        categories: ["action", "shooting"]
    }

];