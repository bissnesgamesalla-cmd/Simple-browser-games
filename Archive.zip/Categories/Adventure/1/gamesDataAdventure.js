//  1 gamesDataAdventure.js
const allGamesDataAdventure = [
    {
        // Tank War Simulator Game
        title: "Escape Police for Brainrots",
        link: "Categories/Adventure/1/Tank-War-Simulator-Game.html",
        image: "Categories/Adventure/1/icon games/Tank War Simulator Game-512x384.webp",
        categories: ["action", "adventure"]
    }

];