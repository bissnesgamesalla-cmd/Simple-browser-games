//  1 gamesDataAction.js
const allGamesDataAction = [
    {
        // Escape Police for Brainrots
        title: "Escape Police for Brainrots",
        link: "Categories/Action/1/Escape-Police-for-Brainrots.html",
        image: "Categories/Action/1/icon games/Escape Police for Brainrots-512x384.webp",
        categories: ["action", "arcade"]
    }

];