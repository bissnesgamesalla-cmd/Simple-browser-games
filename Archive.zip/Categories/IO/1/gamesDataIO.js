// 2 gamesDataIO.js
const allGamesData_IO = [
    {
        // Idle Blocks Tycoon
        title: "Idle Blocks Tycoon",
        link: "Categories/IO/1/Idle-Blocks-Tycoon.html",
        image: "Categories/IO/1/icon games/Idle Blocks Tycoon-512x384.webp",
        categories: ["io", "clicker"]
    }
];