//  1 gamesDataHypercasual.js
const allGamesDataHypercasual = [
    {
        // 1 Mini Dice Chess
        title: "Farm Fresh Fix",
        link: "Categories/Hypercasual/1/Farm-Fresh-Fix.html",
        image: "Categories/Hypercasual/1/icon games/Farm Fresh Fix.webp",
        categories: ["hypercasual", "puzzle"]
    }
     
];