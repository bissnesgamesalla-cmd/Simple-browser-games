
//  1 gamesData_2_players.js
const allGamesData_2_players = [
    {
        // 1 Mini Dice Chess
        title: "Mini Dice Chess",
        link: "Categories/2-players/1/Mini-Dice-Chess.html",
        image: "Categories/2-players/1/icon games/Mini Dice Chess.webp",
        categories: ["2 players", "sports"]
    },
    {   
        // 2 Stickman: Fighter 3D
        title: "Stickman: Fighter 3D",
        link: "Categories/2-players/1/Stickman-Fighter-3D.html",
        image: "Categories/2-players/1/icon games/Stickman  Fighter 3D.webp",
        categories: ["2 players", "3D"]
    },
    {
        // 3 2 Player Games Kids Kitchen
        title: "2 Player Games Kids Kitchen 3D",
        link: "Categories/2-players/1/2-Player-Games-Kids-Kitchen.html",
        image: "Categories/2-players/1/icon games/2 Player Games Kids Kitchen.webp",
        categories: ["2 players", "hypercasual"]

    },
    {
        // 4 Jelly runner platform
        title: "Jelly runner platform",
        link: "Categories/2-players/1/Jelly-runner-platform.html",
        image: "Categories/2-players/1/icon games/Jelly runner platform.webp",
        categories: ["2 players", "arcade"]

    },
    {
        // 5 Chill Tic Tac Toe
        title: "Chill Tic Tac Toe",
        link: "Categories/2-players/1/Chill-Tic-Tac-Toe.html",
        image: "Categories/2-players/1/icon games/Chill Tic Tac Toe.webp ",
        categories: ["2 players", "hypercasual"]

    }
     
];