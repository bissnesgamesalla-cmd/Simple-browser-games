//  1 gamesDataRacing.js
const allGamesDataRacing = [
    {
        // Daily Street Racing 3D
        title: "Mini Dice Chess",
        link: "Categories/Racing/1/Daily-Street-Racing-3D.html",
        image: "Categories/Racing/1/icon games/Daily Street Racing 3D-512x384.webp",
        categories: ["racing", "arcade"]
    },
];