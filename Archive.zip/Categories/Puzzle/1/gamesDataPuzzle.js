
// 2 gamesDataPuzzle.js
const allGamesData_Puzzle = [
    {
        // Fun Memory 1
        title: "Fun memory",
        link: "Categories/Puzzle/1/fun-memory.html",
        image: "Categories/Puzzle/1/icon games/Fun memory.webp",
        categories: ["puzzle", "clicker"]
    },
    {
        // Draw One Part Brain Puzzle 2
        title: "Draw One Part Brain Puzzle",
        link: "Categories/Puzzle/1/draw-one-part-brain-puzzele.html",
        image: "Categories/Puzzle/1/icon games/Draw One Part Brain Puzzle.webp",
        categories: ["puzzle", "hypercasual"]
    },
    {
        // Fruit Drop 3
        title: "Fruit Drop",
        link: "Categories/Puzzle/1/Fruit-Drop.html",
        image: "Categories/Puzzle/1/icon games/Fruit Drop.webp",
        categories: ["puzzle", "clicker"]
    },

    {
        // Trace Learn 4
        title: "Trace Learn",
        link: "Categories/Puzzle/1/Trace-Learn.html",
        image: "Categories/Puzzle/1/icon games/Trace  Learn.webp",
        categories: ["puzzle", "hypercasual"]

    },
    {
        // True or False Game 26 5
        title: "True or Game False 26",
        link: "Categories/Puzzle/1/True-or-False-Game-26.html",
        image: "Categories/Puzzle/1/icon games/True or False Game 26.webp",
        categories: ["puzzle","hypercasual"]

    },
    {
        // Ball and Maze
        title: "Ball and Maze",
        link: "Categories/Puzzle/1/Ball-and-Maze.html",
        image: "Categories/Puzzle/1/icon games/Ball and Maze.webp",
        categories: ["puzzle","hypercasual"]

    },
    {
        // Color Screw 3D
        title: "Color Screw 3D",
        link: "Categories/Puzzle/1/Color-Screw-3D.html",
        image: "Categories/Puzzle/1/icon games/Color Screw 3D.webp",
        categories: ["puzzle", "3D"]

    },
    {
        // Screw Out 3D Relax Unwind
        title: "Screw Out 3D Relax Unwind",
        link: "Categories/Puzzle/1/Screw-Out-3D-Relax-Unwind.html",
        image: "Categories/Puzzle/1/icon games/Screw Out 3D Relax Unwind.webp",
        categories: ["pluzzle"]
    },
    {
        // Spikes Everywhere Game
        title: "Spikes Everywhere Game",
        link:"Categories/Puzzle/1/Spikes-Everywhere-Game.html",
        image: "Categories/Puzzle/1/icon games/Spikes Everywhere Game.webp",
        categories: ["puzzle", "hypercasual"]
    },
    {
        // Dora Puzzle Challenge
        title: "Dora Puzzle Challenge",
        link: "Categories/Puzzle/1/Dora-Puzzle-Challenge.html",
        image: "Categories/Puzzle/1/icon games/Dora Puzzle Challenge.webp",
        categories: ["puzzle", "arcade"]
    }
];
